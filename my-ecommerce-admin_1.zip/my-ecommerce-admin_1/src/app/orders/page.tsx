import OrdersPage from '../Components/OrdersPage';

export default function Orders() {
  return <OrdersPage />;
}
