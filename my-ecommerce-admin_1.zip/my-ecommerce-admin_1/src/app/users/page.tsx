import UsersPage from '../Components/UsersPage';

export default function Users() {
  return <UsersPage />;
}
