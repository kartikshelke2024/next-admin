import { NextResponse } from 'next/server';
import { openDb } from '../../../../db';

export async function GET() {
  const db = await openDb();
  const products = await db.all('SELECT * FROM products');
  return NextResponse.json(products);
}

export async function POST(request: Request) {
  const db = await openDb();
  const { name, description, price, stock, category } = await request.json();
  await db.run(
    'INSERT INTO products (name, description, price, stock, category) VALUES (?, ?, ?, ?, ?)',
    [name, description, price, stock, category]
  );
  return NextResponse.json({ message: 'Product added successfully' });
}

export async function PUT(request: Request) {
  const db = await openDb();
  const { id, name, description, price, stock, category } = await request.json();
  await db.run(
    'UPDATE products SET name = ?, description = ?, price = ?, stock = ?, category = ? WHERE id = ?',
    [name, description, price, stock, category, id]
  );
  return NextResponse.json({ message: 'Product updated successfully' });
}

export async function DELETE(request: Request) {
  const db = await openDb();
  const { id } = await request.json();
  await db.run('DELETE FROM products WHERE id = ?', [id]);
  return NextResponse.json({ message: 'Product deleted successfully' });
}
