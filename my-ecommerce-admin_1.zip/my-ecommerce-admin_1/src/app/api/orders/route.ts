import { NextResponse } from 'next/server';
import { openDb } from '../../../../db';

export async function GET() {
  const db = await openDb();
  const orders = await db.all('SELECT * FROM orders');
  return NextResponse.json(orders);
}

export async function POST(request: Request) {
  const db = await openDb();
  const { user_id, product_id, quantity, status } = await request.json();
  await db.run(
    'INSERT INTO orders (user_id, product_id, quantity, status) VALUES (?, ?, ?, ?)',
    [user_id, product_id, quantity, status]
  );
  return NextResponse.json({ message: 'Order added successfully' });
}

export async function PUT(request: Request) {
  const db = await openDb();
  const { id, user_id, product_id, quantity, status } = await request.json();
  await db.run(
    'UPDATE orders SET user_id = ?, product_id = ?, quantity = ?, status = ? WHERE id = ?',
    [user_id, product_id, quantity, status, id]
  );
  return NextResponse.json({ message: 'Order updated successfully' });
}

export async function DELETE(request: Request) {
  const db = await openDb();
  const { id } = await request.json();
  await db.run('DELETE FROM orders WHERE id = ?', [id]);
  return NextResponse.json({ message: 'Order deleted successfully' });
}
