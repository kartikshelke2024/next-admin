import { NextResponse } from 'next/server';
import { openDb } from '../../../../db';

export async function GET() {
  const db = await openDb();
  const users = await db.all('SELECT * FROM users');
  return NextResponse.json(users);
}

export async function POST(request: Request) {
  const db = await openDb();
  const { name, email, password, role } = await request.json();
  await db.run(
    'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
    [name, email, password, role]
  );
  return NextResponse.json({ message: 'User added successfully' });
}

export async function PUT(request: Request) {
  const db = await openDb();
  const { id, name, email, password, role } = await request.json();
  await db.run(
    'UPDATE users SET name = ?, email = ?, password = ?, role = ? WHERE id = ?',
    [name, email, password, role, id]
  );
  return NextResponse.json({ message: 'User updated successfully' });
}

export async function DELETE(request: Request) {
  const db = await openDb();
  const { id } = await request.json();
  await db.run('DELETE FROM users WHERE id = ?', [id]);
  return NextResponse.json({ message: 'User deleted successfully' });
}
