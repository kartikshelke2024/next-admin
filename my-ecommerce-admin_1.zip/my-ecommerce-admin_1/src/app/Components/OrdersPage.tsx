"use client";

import { useState, useEffect } from 'react';
import { Order } from '../../types';

function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [userId, setUserId] = useState('');
  const [productId, setProductId] = useState('');
  const [quantity, setQuantity] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    async function fetchOrders() {
      const response = await fetch('/api/orders');
      const data: Order[] = await response.json();
      setOrders(data);
    }
    fetchOrders();
  }, []);

  async function handleAddOrder() {
    await fetch('/api/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ user_id: userId, product_id: productId, quantity, status }),
    });
    setUserId('');
    setProductId('');
    setQuantity('');
    setStatus('');
    const response = await fetch('/api/orders');
    const data: Order[] = await response.json();
    setOrders(data);
  }

  async function handleUpdateOrder(id: number) {
    // Implement update logic here
  }

  async function handleDeleteOrder(id: number) {
    await fetch('/api/orders', {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id }),
    });
    const updatedOrders = orders.filter(order => order.id !== id);
    setOrders(updatedOrders);
  }

  return (
    <div>
      <h1>Orders</h1>
      <form onSubmit={(e) => {
        e.preventDefault();
        handleAddOrder();
      }}>
        <input type="text" value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="User ID" required />
        <input type="text" value={productId} onChange={(e) => setProductId(e.target.value)} placeholder="Product ID" required />
        <input type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} placeholder="Quantity" required />
        <input type="text" value={status} onChange={(e) => setStatus(e.target.value)} placeholder="Status" required />
        <button type="submit">Add Order</button>
      </form>
      <ul>
        {orders.map(order => (
          <li key={order.id}>
            User ID: {order.user_id} - Product ID: {order.product_id} - Quantity: {order.quantity} - Status: {order.status}
            <button onClick={() => handleUpdateOrder(order.id)}>Update</button>
            <button onClick={() => handleDeleteOrder(order.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default OrdersPage;
