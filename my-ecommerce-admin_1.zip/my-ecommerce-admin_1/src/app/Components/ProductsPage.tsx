"use client";

import { useState, useEffect } from 'react';
import { Product } from '../../types';

function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');
  const [category, setCategory] = useState('');

  useEffect(() => {
    async function fetchProducts() {
      const response = await fetch('/api/products');
      const data: Product[] = await response.json();
      setProducts(data);
    }
    fetchProducts();
  }, []);

  async function handleAddProduct() {
    await fetch('/api/products', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, description, price, stock, category }),
    });
    setName('');
    setDescription('');
    setPrice('');
    setStock('');
    setCategory('');
    const response = await fetch('/api/products');
    const data: Product[] = await response.json();
    setProducts(data);
  }

  async function handleUpdateProduct(id: number) {
    // Implement update logic here
  }

  async function handleDeleteProduct(id: number) {
    await fetch('/api/products', {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id }),
    });
    const updatedProducts = products.filter(product => product.id !== id);
    setProducts(updatedProducts);
  }

  return (
    <div>
      <h1>Products</h1>
      <form onSubmit={(e) => {
        e.preventDefault();
        handleAddProduct();
      }}>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" required />
        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" required />
        <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Price" required />
        <input type="number" value={stock} onChange={(e) => setStock(e.target.value)} placeholder="Stock" required />
        <input type="text" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Category" required />
        <button type="submit">Add Product</button>
      </form>
      <ul>
        {products.map(product => (
          <li key={product.id}>
            {product.name} - {product.description} - ${product.price} - {product.stock} - {product.category}
            <button onClick={() => handleUpdateProduct(product.id)}>Update</button>
            <button onClick={() => handleDeleteProduct(product.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ProductsPage;
