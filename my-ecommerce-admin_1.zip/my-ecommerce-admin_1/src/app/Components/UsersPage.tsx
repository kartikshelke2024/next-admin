"use client";

import { useState, useEffect } from 'react';
import { User } from '../../types';

function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');

  useEffect(() => {
    async function fetchUsers() {
      const response = await fetch('/api/users');
      const data: User[] = await response.json();
      setUsers(data);
    }
    fetchUsers();
  }, []);

  async function handleAddUser() {
    await fetch('/api/users', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, email, password, role }),
    });
    setName('');
    setEmail('');
    setPassword('');
    setRole('');
    const response = await fetch('/api/users');
    const data: User[] = await response.json();
    setUsers(data);
  }

  async function handleUpdateUser(id: number) {
    // Implement update logic here
  }

  async function handleDeleteUser(id: number) {
    await fetch('/api/users', {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id }),
    });
    const updatedUsers = users.filter(user => user.id !== id);
    setUsers(updatedUsers);
  }

  return (
    <div>
      <h1>Users</h1>
      <form onSubmit={(e) => {
        e.preventDefault();
        handleAddUser();
      }}>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" required />
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required />
        <input type="text" value={role} onChange={(e) => setRole(e.target.value)} placeholder="Role" required />
        <button type="submit">Add User</button>
      </form>
      <ul>
        {users.map(user => (
          <li key={user.id}>
            {user.name} - {user.email} - {user.role}
            <button onClick={() => handleUpdateUser(user.id)}>Update</button>
            <button onClick={() => handleDeleteUser(user.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default UsersPage;
