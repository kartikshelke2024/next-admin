import ProductsPage from '../Components/ProductsPage';

export default function Products() {
  return <ProductsPage />;
}
