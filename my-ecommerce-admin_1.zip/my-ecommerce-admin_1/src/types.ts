// src/app/types.ts
export interface User {
  id: number;
  name: string;
  email: string;
  password: string;
  role: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
}

export interface Order {
  id: number;
  user_id: number;
  product_id: number;
  quantity: number;
  status: string;
}
